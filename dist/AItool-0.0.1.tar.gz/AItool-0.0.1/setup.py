# coding:utf-8
# python setup.py sdist bdist_wheel
# reference: https://stackoverflow.com/questions/37031456/include-pyd-files-in-python-packages

import setuptools 
 
setuptools.setup(
    name="AItool",                                        # package name
    version="0.0.1",                                      # version
    author="Zhipan wang",                                 # author name
    author_email="1044625113@qq.com",                     # email
    description="change detection on large-scale image",  # description
    include_package_data=True,
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',    # software version surpport
)

